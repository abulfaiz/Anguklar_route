import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  getAllUsers(){
    return [ // Array
      {id:1,name:'a',age:20,gender:'male'}, // object
      {id:2,name:'b',age:22,gender:'male'}
    ];

  }
getUser(id:number){
  return this.getAllUsers();

}

  }

